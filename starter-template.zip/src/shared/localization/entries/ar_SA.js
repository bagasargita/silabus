import saMessages from '../locales/ar_SA.json';

const saLang = {
  messages: {
    ...saMessages,
  },
  locale: 'ar-SA',
};
export default saLang;
