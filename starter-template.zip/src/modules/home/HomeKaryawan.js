import React from "react";

const HomeKaryawan = () => {
    return(
        <h1>Ini adalah Halaman Karyawan </h1>
    );
}
export default HomeKaryawan;