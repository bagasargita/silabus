import React from "react";

const ComponentKegiatan = () => {
    return(
        <>
            <h1>Component Kegiatan</h1>
        </>
    );
}
export default ComponentKegiatan;
