import React from 'react';

const DummyItem = ({item}) => {
  return <div>{item}</div>;
};

export default DummyItem;
